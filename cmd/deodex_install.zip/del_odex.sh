#!/sbin/sh

rm -rf /system/app/*.odex
rm -rf /system/framework/*.odex
rm -rf /system/priv-app/*.odex
exit 0
